
let messages = [];
let chats = JSON.parse(localStorage.getItem("chatgpt_history")) || [];
let isLoading = false;


let inputField = document.getElementById("messageInput");
let sendButton = document.getElementById("sendBtn");
let chatBox = document.getElementById("chatBox");
let historyList = document.getElementById("historyList");
let welcomeText = document.querySelector(".aech");
let newChatBtn = document.querySelector(".para");


showHistory();


sendButton.addEventListener("click", sendMessage);


inputField.addEventListener("keydown", function(event) {
    if (event.key === "Enter") {
        event.preventDefault();
        sendMessage();
    }
});

inputField.addEventListener("input", function() {
    inputField.style.height = "auto";
    inputField.style.height = inputField.scrollHeight + "px";
    if (inputField.scrollHeight > 180) {
        inputField.style.height = "180px";
    }
});


newChatBtn.addEventListener("click", startNewChat);



function sendMessage() {
    
    if (isLoading) return;

    let userMessage = inputField.value.trim();
    if (userMessage === "") return;

    isLoading = true;
    welcomeText.style.display = "none";

    inputField.value = "";
    inputField.style.height = "54px";

    
    addMessage(userMessage, "user");
    messages.push({ role: "user", content: userMessage });
    saveChat();

    let botElement = addMessage("Sabar karle...", "bot");

    getAIResponse(userMessage, botElement);
}



function getAIResponse(userMessage, botElement) {
    
   
    if (!window.puter || !window.puter.ai) {
        let errorMsg = " Puter AI available nahi hai! Internet check karo.";
        showBotReply(botElement, errorMsg);
        return;
    }

    
    window.puter.ai.chat(
        [{ role: "user", content: userMessage }],
        { model: "gpt-4o-mini" }
    )
    .then(function(result) {
        let reply = result;
        if (result.message && result.message.content) {
            reply = result.message.content;
        }
        showBotReply(botElement, reply);
    })
    .catch(function(error) {
        console.log(" API Error:", error);
        let errorMsg = " API Error: " + error.message;
        showBotReply(botElement, errorMsg);
    });
}


function showBotReply(element, reply) {
    messages.push({ role: "assistant", content: reply });
    saveChat();
    typeWriter(element, reply);
}


function typeWriter(element, text) {
    element.innerHTML = simpleFormat(text);
    isLoading = false;
    inputField.focus();
    chatBox.scrollTop = chatBox.scrollHeight;
}


function simpleFormat(text) {
    let result = "";

    for (let i = 0; i < text.length; i++) {
        if (text[i] === '\n') {
            result = result + "<br>";
        } else {
            result = result + text[i];
        }
    }

    let boldParts = result.split("**");
    let boldResult = "";
    for (let i = 0; i < boldParts.length; i++) {
        if (i % 2 === 0) {
            boldResult = boldResult + boldParts[i];
        } else {
            boldResult = boldResult + "<strong>" + boldParts[i] + "</strong>";
        }
    }
    result = boldResult;

    let lines = result.split("<br>");
    let headingResult = "";
    for (let i = 0; i < lines.length; i++) {
        let line = lines[i];
        if (line.startsWith("### ")) {
            line = line.replace("### ", "");
            headingResult = headingResult + "<h3>" + line + "</h3>";
        } else {
            headingResult = headingResult + line + "<br>";
        }
    }
    result = headingResult;

    return result;
}


function addMessage(text, type) {
    let messageDiv = document.createElement("div");
    messageDiv.classList.add("msg", type);
    messageDiv.innerHTML = simpleFormat(text);
    chatBox.appendChild(messageDiv);
    chatBox.scrollTop = chatBox.scrollHeight;
    return messageDiv;
}


function saveChat() {
    if (!chatId) {
        chatId = "chat_" + Date.now();

        let firstMessage = "New Chat";
        if (messages.length > 0) {
            firstMessage = messages[0].content;
            if (firstMessage.length > 25) {
                firstMessage = firstMessage.substring(0, 25) + "...";
            }
        }

        let newChat = {
            id: chatId,
            title: firstMessage,
            messages: messages
        };
        chats.unshift(newChat);

    } else {
        for (let i = 0; i < chats.length; i++) {
            if (chats[i].id === chatId) {
                chats[i].messages = messages;
                break;
            }
        }
    }

    localStorage.setItem("chatgpt_history", JSON.stringify(chats));
    showHistory();
}



function showHistory() {
    historyList.innerHTML = "";

    for (let i = 0; i < chats.length; i++) {
        let listItem = document.createElement("li");
        listItem.innerText = chats[i].title;

        listItem.addEventListener("click", function() {
            loadChat(chats[i].id);
        });

        historyList.appendChild(listItem);
    }
}



function loadChat(id) {
    let selectedChat = null;

    for (let i = 0; i < chats.length; i++) {
        if (chats[i].id === id) {
            selectedChat = chats[i];
            break;
        }
    }

    if (selectedChat === null) return;

    chatId = selectedChat.id;
    messages = [];

    for (let i = 0; i < selectedChat.messages.length; i++) {
        messages.push(selectedChat.messages[i]);
    }

    chatBox.innerHTML = "";
    welcomeText.style.display = "none";

    for (let i = 0; i < messages.length; i++) {
        let type = "bot";
        if (messages[i].role === "user") {
            type = "user";
        }
        addMessage(messages[i].content, type);
    }
}


function startNewChat() {
    chatId = null;
    messages = [];
    chatBox.innerHTML = "";
    welcomeText.style.display = "block";
    inputField.value = "";
    inputField.style.height = "54px";
    inputField.focus();
}